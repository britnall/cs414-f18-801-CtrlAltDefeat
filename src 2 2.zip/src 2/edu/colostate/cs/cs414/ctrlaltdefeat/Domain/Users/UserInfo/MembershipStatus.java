package edu.colostate.cs.cs414.ctrlaltdefeat.Domain.Users.UserInfo;

public enum MembershipStatus {
   ACTIVE,
   INACTIVE
}
