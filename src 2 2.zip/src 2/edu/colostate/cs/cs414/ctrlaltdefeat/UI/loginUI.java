package edu.colostate.cs.cs414.ctrlaltdefeat.UI;

public class loginUI {

}
