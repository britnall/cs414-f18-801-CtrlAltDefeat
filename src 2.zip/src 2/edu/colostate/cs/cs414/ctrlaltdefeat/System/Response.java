package edu.colostate.cs.cs414.ctrlaltdefeat.System;

public class Response {
   
   public boolean successful;   
   public String info;   
   
   public Response(){
      this.successful = false;
      this.info = "";
   }

}
