package edu.colostate.cs.cs414.ctrlaltdefeat.Domain.Users;

public enum UserType {
   MANAGER,
   TRAINER
}
